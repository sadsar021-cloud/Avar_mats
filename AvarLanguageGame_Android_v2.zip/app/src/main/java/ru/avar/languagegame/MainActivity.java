package ru.avar.languagegame;

import android.app.Activity;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.graphics.Typeface;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;
import android.content.SharedPreferences;
import java.util.*;

public class MainActivity extends Activity {
    private final int dark = Color.rgb(35, 53, 57);
    private final int green = Color.rgb(35, 112, 99);
    private final int cream = Color.rgb(246, 244, 235);
    private final int gold = Color.rgb(190, 145, 62);

    private LinearLayout root;
    private SharedPreferences prefs;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private int score = 0;
    private int quizIndex = 0;
    private int quizCorrect = 0;

    // Словарь намеренно небольшой: новые слова добавляются после проверки носителем языка.
    private final String[][] dictionary = {
        {"Салам", "Приветствие", "Salam", "Приветствие"},
        {"Баркала", "Спасибо", "Barkala", "Вежливые слова"}
    };

    private final String[][] quiz = {
        {"Как переводится «Баркала»?", "Спасибо", "До свидания", "Добро пожаловать", "0"},
        {"Какое слово означает приветствие?", "Салам", "Баркала", "Рахъ", "0"},
        {"Как сказать «спасибо»?", "Баркала", "Салам", "Не знаю", "0"}
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("avar_progress", MODE_PRIVATE);
        score = prefs.getInt("score", 0);
        try {
            tts = new TextToSpeech(this, status -> {
                if (status == TextToSpeech.SUCCESS) {
                    // Устройство может не иметь движка аварского языка.
                    ttsReady = true;
                }
            });
        } catch (Exception ignored) {}
        showHome();
    }

    private TextView label(String s, int size, boolean bold, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        t.setPadding(8, 10, 8, 10);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    private Button makeButton(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(16);
        b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(green));
        return b;
    }

    private void page(String title, String subtitle) {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setBackgroundColor(cream);
        outer.setPadding(20, 18, 20, 22);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(outer);
        setContentView(scroll);
        root = outer;
        TextView h = label(title, 27, true, green);
        root.addView(h);
        if (subtitle != null && !subtitle.isEmpty())
            root.addView(label(subtitle, 15, false, dark));
        View line = new View(this);
        line.setBackgroundColor(gold);
        root.addView(line, new LinearLayout.LayoutParams(-1, 2));
    }

    private void addGap() {
        TextView gap = new TextView(this);
        gap.setHeight(8);
        root.addView(gap);
    }

    private void showHome() {
        page("АВАР МАЦӀ", "Изучай аварский язык: слова, выражения и разговорная практика");
        root.addView(label("⛰ Дагестан начинается с языка", 18, true, dark));
        root.addView(label("Твои очки: " + score + " ⭐", 20, true, gold));
        addGap();

        Button lessons = makeButton("📚 Уроки и словарь");
        lessons.setOnClickListener(v -> showDictionary());
        root.addView(lessons);

        Button quizButton = makeButton("🧠 Викторина");
        quizButton.setOnClickListener(v -> startQuiz());
        root.addView(quizButton);

        Button progress = makeButton("🏆 Мой прогресс");
        progress.setOnClickListener(v -> showProgress());
        root.addView(progress);

        addGap();
        root.addView(label("В версии 2.0 добавлены экран прогресса, тематические карточки и викторина. Словарь будет расширяться по мере проверки переводов.", 14, false, dark));
        root.addView(label("Важно: озвучка зависит от установленных голосов Android. Если аварский голос недоступен, приложение не будет выдавать русское произношение за аварское.", 13, false, dark));
    }

    private void showDictionary() {
        page("Первые слова", "Читай аварское слово, перевод и подсказку по произношению");
        for (String[] item : dictionary) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(12, 10, 12, 10);
            card.setBackgroundColor(Color.WHITE);
            TextView avar = label(item[0], 26, true, green);
            card.addView(avar);
            card.addView(label(item[1], 18, true, dark));
            card.addView(label("Транскрипция: " + item[2], 14, false, dark));
            card.addView(label("Раздел: " + item[3], 13, false, gold));
            Button speak = makeButton("🔊 Попробовать озвучить");
            speak.setOnClickListener(v -> speakWord(item[0]));
            card.addView(speak);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.setMargins(0, 10, 0, 10);
            root.addView(card, lp);
        }
        Button back = makeButton("На главную");
        back.setOnClickListener(v -> showHome());
        root.addView(back);
    }

    private void speakWord(String word) {
        if (tts == null || !ttsReady) {
            Toast.makeText(this, "Синтез речи пока недоступен на устройстве.", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            int result = tts.setLanguage(new Locale("av"));
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Toast.makeText(this, "На устройстве нет аварского голоса. Нужна проверенная аудиозапись носителя.", Toast.LENGTH_LONG).show();
            } else {
                tts.speak(word, TextToSpeech.QUEUE_FLUSH, null, "avar_word");
            }
        } catch (Exception e) {
            Toast.makeText(this, "Не удалось запустить озвучку.", Toast.LENGTH_SHORT).show();
        }
    }

    private void startQuiz() {
        quizIndex = 0;
        quizCorrect = 0;
        showQuestion();
    }

    private void showQuestion() {
        if (quizIndex >= quiz.length) {
            int earned = quizCorrect * 10;
            score += earned;
            prefs.edit().putInt("score", score)
                    .putInt("best", Math.max(prefs.getInt("best", 0), quizCorrect))
                    .putInt("completed", prefs.getInt("completed", 0) + 1)
                    .apply();
            page("Викторина завершена!", "Отличная работа — продолжай учиться");
            root.addView(label("Правильных ответов: " + quizCorrect + " из " + quiz.length, 22, true, green));
            root.addView(label("Получено очков: +" + earned, 20, true, gold));
            Button again = makeButton("Пройти ещё раз");
            again.setOnClickListener(v -> startQuiz());
            root.addView(again);
            Button home = makeButton("На главную");
            home.setOnClickListener(v -> showHome());
            root.addView(home);
            return;
        }

        page("Вопрос " + (quizIndex + 1) + " из " + quiz.length, "Выбери правильный перевод");
        final int current = quizIndex;
        root.addView(label(quiz[current][0], 21, true, dark));
        for (int i = 1; i <= 3; i++) {
            final int chosen = i;
            Button option = makeButton(quiz[current][i]);
            option.setOnClickListener(v -> {
                boolean correct = (chosen - 1) == Integer.parseInt(quiz[current][4]);
                if (correct) {
                    quizCorrect++;
                    Toast.makeText(this, "Верно!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Пока неверно. Повтори слово в уроке.", Toast.LENGTH_SHORT).show();
                }
                quizIndex++;
                showQuestion();
            });
            root.addView(option);
        }
        Button home = makeButton("Выйти на главную");
        home.setOnClickListener(v -> showHome());
        root.addView(home);
    }

    private void showProgress() {
        page("Мой прогресс", "Твои результаты сохраняются на этом устройстве");
        root.addView(label("⭐ Всего очков: " + score, 22, true, gold));
        root.addView(label("🏅 Лучший результат: " + prefs.getInt("best", 0) + " правильных ответов", 17, true, dark));
        root.addView(label("📖 Завершено викторин: " + prefs.getInt("completed", 0), 17, true, dark));
        Button back = makeButton("На главную");
        back.setOnClickListener(v -> showHome());
        root.addView(back);
    }

    @Override protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }
}
